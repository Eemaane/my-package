def oddnum(item):
    for i in item:
        if i%2 == 1:
            return 1**0.5
""" function to return square root of odd numbers in a list."""
        

